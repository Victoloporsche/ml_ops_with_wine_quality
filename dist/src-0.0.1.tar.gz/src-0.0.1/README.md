MLOPS with wine quality data.
